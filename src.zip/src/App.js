import React, { useState } from "react";
import "./App.css";

function App() {
  const [productOne, setProductOne] = useState("");
  const [productTwo, setProductTwo] = useState("");
  const [comparisonResults, setComparisonResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleCompare = async () => {
    if (!productOne || !productTwo) {
      setError("Please enter both product names.");
      return;
    }

    setLoading(true);
    setError(null);
    setComparisonResults([]);
    try {
      const response = await fetch("http://127.0.0.1:5000/compare", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ product_names: [productOne, productTwo] }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      setComparisonResults(data.comparison);
    } catch (err) {
      setError("Failed to fetch product data. Please try again.");
      console.error("Error:", err);
    }

    setLoading(false);
  };

  return (
    <div className="stApp">
      <div className="container">
        <h1>🌱 Eco-Friendly Product Comparer</h1>
        <p>Enter two product names to compare their eco-scores.</p>

        <div className="input-container">
          <input
            type="text"
            placeholder="Enter first product"
            value={productOne}
            onChange={(e) => setProductOne(e.target.value)}
          />
          <input
            type="text"
            placeholder="Enter second product"
            value={productTwo}
            onChange={(e) => setProductTwo(e.target.value)}
          />
        </div>

        <button onClick={handleCompare} disabled={loading}>
          {loading ? "Comparing..." : "Compare Products"}
        </button>

        {error && <p className="error">{error}</p>}

        {comparisonResults.length > 0 && (
          <div className="comparison-container">
            {comparisonResults.map((product, index) => {
              // Adjust milk and nuts
              const mergedGoodIngredients = product.good_ingredients.concat(
                product.harmful_ingredients.filter((item) =>
                  ["milk", "nuts"].includes(item.toLowerCase())
                )
              );

              const filteredHarmfulIngredients =
                product.harmful_ingredients.filter(
                  (item) => !["milk", "nuts"].includes(item.toLowerCase())
                );

              const noGood = mergedGoodIngredients.length === 0;
              const noHarmful = filteredHarmfulIngredients.length === 0;
              const notEnoughData = noGood && noHarmful;

              return (
                <div key={index} className="product-card">
                  <h3>{product.name}</h3>
                  {product.image && (
                    <img
                      src={product.image}
                      alt={product.name}
                      style={{ display: "block", margin: "0 auto" }}
                    />
                  )}
                  <p>
                    <strong>Eco Score:</strong>{" "}
                    {notEnoughData ? "-/100" : `${product.eco_score}/100`}
                  </p>

                  {notEnoughData ? (
                    <p>
                      <strong>Note:</strong> There is not enough data to
                      determine the eco score of the product.
                    </p>
                  ) : (
                    <>
                      {mergedGoodIngredients.length > 0 && (
                        <p>
                          <strong>Good Ingredients:</strong>{" "}
                          {mergedGoodIngredients.join(", ")}
                        </p>
                      )}
                      {filteredHarmfulIngredients.length > 0 && (
                        <p>
                          <strong>Harmful Ingredients:</strong>{" "}
                          {filteredHarmfulIngredients.join(", ")}
                        </p>
                      )}
                    </>
                  )}

                  <p>
                    <strong>Packaging:</strong>{" "}
                    {product.packaging && product.packaging.length > 0
                      ? product.packaging.join(", ")
                      : "Packaging information not available"}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
